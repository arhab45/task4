<?php
$_name = $_POST['name'];
$_umur = $_POST['umur'];
$_gender = $_POST['gender'];
$_pendidikan = $_POST['pendidikan'];
$_hobi = $_POST['hobi'];

echo  "Nama Lengkap :".$_name;
echo "<br>";
echo  "Umur :".$_umur;
echo "<br>";
echo  "Gender :".$_gender;
echo "<br>";
echo  "Pendidikan :".$_pendidikan;
echo "<br>";
echo  "Hobi :".$_hobi;
echo "<br>";


?>
<br><br>
<a href="hasil.html">submit</a>
